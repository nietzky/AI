import React from "react";

function Sidebar({ sessions, activeSessionId, onSessionClick }) {
  return (
    <div style={{ width: "300px", borderRight: "1px solid #ccc", overflowY: "auto" }}>
      <h2 style={{ padding: "1rem" }}>Chat History</h2>
      {sessions.map((session) => (
        <div
          key={session.session_id}
          onClick={() => onSessionClick(session)}
          style={{
            padding: "1rem",
            borderBottom: "1px solid #eee",
            cursor: "pointer",
            backgroundColor: session.session_id === activeSessionId ? "#f0f0f0" : "white",
          }}
        >
          <strong>{session.session_id}</strong>
          <p style={{ fontSize: "0.9em", color: "#555" }}>{session.latest_message}</p>
        </div>
      ))}
    </div>
  );
}

export default Sidebar;
