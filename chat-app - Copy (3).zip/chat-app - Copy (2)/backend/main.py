from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
from datetime import datetime
import json
import sqlite3
from pydantic_ai import Agent
from pydantic_ai.messages import ModelMessage, ModelRequest, ModelResponse, TextPart, UserPromptPart, SystemPromptPart
from pydantic_ai.models.openai import OpenAIModel
from pydantic_ai.providers.openai import OpenAIProvider
import logging
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# ✅ CORS setup must go right after app creation
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def main():
    return {"message": "Hello World"}

# OpenAI model setup
model = OpenAIModel('gpt-4o', provider=OpenAIProvider(api_key=''))
agent = Agent(model, system_prompt='Be helpful and concise.')

# Set up basic logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# SQLite database class
class SQLiteDB:
    def __init__(self, db_name='conversations.db'):
        self.conn = sqlite3.connect(db_name)
        self.create_table()

    def create_table(self):
        with self.conn:
            self.conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_history3 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT, 
                message_list TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

    def add_messages(self, session_id: str, messages: str) -> None:
        self.conn.execute("INSERT INTO conversation_history3 (session_id, message_list) VALUES (?, ?)", (session_id, messages))
        self.conn.commit()

    def get_history(self, session_id: str) -> List[ModelMessage]:
        def _parse_message(data: bytes) -> list[ModelMessage]:
            json_data = json.loads(data.decode('utf-8'))
            messages = []

            for msg in json_data:
                parts = []
                for part in msg['parts']:
                    part_kind = part['part_kind']

                    if part_kind == 'system-prompt':
                        parts.append(SystemPromptPart(content=part['content'], dynamic_ref=part.get('dynamic_ref')))
                    elif part_kind == 'user-prompt':
                        parts.append(UserPromptPart(
                            content=part['content'],
                            timestamp=datetime.fromisoformat(part['timestamp']),
                            part_kind=part['part_kind']
                        ))
                    elif part_kind == 'text':
                        parts.append(TextPart(content=part['content'], part_kind=part['part_kind']))
                    else:
                        raise ValueError(f"Unknown part_kind: {part_kind}")

                # Create ModelRequest or ModelResponse
                if msg['kind'] == 'request':
                    messages.append(ModelRequest(parts=parts, kind='request'))
                elif msg['kind'] == 'response':
                    messages.append(ModelResponse(
                        parts=parts,
                        model_name=msg.get('model_name'),
                        timestamp=datetime.fromisoformat(msg['timestamp']),
                        kind='response'
                    ))
                else:
                    raise ValueError(f"Unknown message kind: {msg['kind']}")

            return messages
        
        cursor = self.conn.execute(f"SELECT message_list FROM conversation_history3 WHERE session_id = '{session_id}' ORDER BY timestamp DESC LIMIT 1")
        messages = cursor.fetchall()
        model_messages: list[ModelMessage] = []

        for item in messages:
            model_messages.extend(_parse_message(item[0]))

        return model_messages

# Request model for the chat
class ChatRequest(BaseModel):
    session_id: str
    message: str

# Response model for the chat
class ChatResponse(BaseModel):
    message: str

# Chat endpoint
@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    logger.info("Received chat request: %s", request)

    try:
        db = SQLiteDB()
        logger.info("DB connected.")
        session_id = request.session_id
        message = request.message

        message_history = db.get_history(session_id)
        logger.info("Got message history with %d messages", len(message_history))

        response = await agent.run(message, message_history=message_history)
        logger.info("Agent responded.")

        db.add_messages(session_id, response.all_messages_json())
        logger.info("Stored response.")
       # text = response.data.text if hasattr(response, "data") else response
       # return ChatResponse(message=text)
        return ChatResponse(message=response.output)

    except Exception as e:
        logger.exception("Chat endpoint failed")
        raise HTTPException(status_code=500, detail=str(e))
    

@app.get("/sessions")
async def get_sessions():
    try:
        db = SQLiteDB()
        cursor = db.conn.execute("""
            SELECT session_id, message_list, MAX(timestamp) as last_updated
            FROM conversation_history3
            GROUP BY session_id
            ORDER BY last_updated DESC
        """)
        rows = cursor.fetchall()

        all_sessions = []

        for session_id, message_list, last_updated in rows:
            try:
                raw_messages = json.loads(message_list)

                # Extract latest message content for convenience
                latest = None
                for msg in reversed(raw_messages):
                    if msg["kind"] == "request":
                        latest = next((p["content"] for p in msg["parts"] if p["part_kind"] == "user-prompt"), None)
                        break
                    elif msg["kind"] == "response":
                        latest = next((p["content"] for p in msg["parts"] if p["part_kind"] == "text"), None)
                        break

                all_sessions.append({
                    "session_id": session_id,
                    "last_updated": last_updated,
                    "latest_message": latest,
                    "messages": raw_messages
                })

            except Exception as e:
                logger.warning(f"Failed to parse messages for session {session_id}: {e}")

        return JSONResponse(content=all_sessions)

    except Exception as e:
        logger.exception("Failed to fetch session histories")
        raise HTTPException(status_code=500, detail="Failed to retrieve session histories.")


# Simple GET method that returns "Hello, World"
@app.get("/hello")
def read_hello():
    return {"message": "Hello, World"}

# To run the FastAPI app, use `uvicorn` like this:
# uvicorn your_filename:app --reload

