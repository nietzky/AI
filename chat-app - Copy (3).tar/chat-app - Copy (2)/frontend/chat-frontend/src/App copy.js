import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  CircularProgress,
  IconButton,
  Stack,
} from '@mui/material';
import { Sparkles } from 'lucide-react';

function ChatApp() {
  const [sessionId] = useState(() => crypto.randomUUID());
  const [message, setMessage] = useState('');
  const [chatLog, setChatLog] = useState([]);
  const [loading, setLoading] = useState(false);

  const addMessage = (sender, text) => {
    setChatLog((prev) => [...prev, { sender, text }]);
  };

  const sendMessage = async () => {
    if (!message.trim()) return;

    addMessage('user', message);
    setMessage('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, message }),
      });

      const data = await response.json();
      addMessage('bot', data.message);
    } catch (error) {
      console.error('Error:', error);
      addMessage('bot', 'Error connecting to server.');
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <Box sx={{ bgcolor: '#f8f9fa', minHeight: '100vh', py: 4 }}>
      <Container maxWidth="sm">
        <Typography variant="h5" align="center" gutterBottom sx={{ fontWeight: 500 }}>
          What can I help with?
        </Typography>

        <Box
          sx={{
            height: 420,
            overflowY: 'auto',
            p: 2,
            bgcolor: 'white',
            borderRadius: 3,
            border: '1px solid #e0e0e0',
            mb: 2,
          }}
        >
          <Stack spacing={2}>
            {chatLog.map((entry, idx) => (
              <Box
                key={idx}
                sx={{
                  display: 'flex',
                  justifyContent:
                    entry.sender === 'user' ? 'flex-end' : 'flex-start',
                }}
              >
                {entry.sender === 'bot' && (
                  <IconButton size="small" sx={{ mt: 0.5, color: 'primary.main' }}>
                    <Sparkles size={18} />
                  </IconButton>
                )}
                <Box
                  sx={{
                    bgcolor: entry.sender === 'user' ? '#1976d2' : '#f1f3f5',
                    color: entry.sender === 'user' ? '#fff' : '#333',
                    px: 2,
                    py: 1,
                    borderRadius: 2,
                    maxWidth: '70%',
                    ml: entry.sender === 'user' ? 0 : 1,
                    mr: entry.sender === 'user' ? 1 : 0,
                    fontSize: '0.875rem',
                    wordBreak: 'break-word',
                  }}
                >
                  {entry.sender === 'bot' ? (
                    <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      code({ node, inline, className, children, ...props }) {
                        return (
                          <Box
                            component="code"
                            sx={{
                              bgcolor: inline ? '#eaeaea' : '#f6f8fa',
                              px: inline ? 0.5 : 2,
                              py: inline ? 0 : 1,
                              fontSize: '0.85rem',
                              fontFamily: 'monospace',
                              borderRadius: 1,
                              overflowX: 'auto',
                              display: inline ? 'inline' : 'block',
                              whiteSpace: 'pre-wrap',
                            }}
                            {...props}
                          >
                            {children}
                          </Box>
                        );
                      },
                      pre({ node, children, ...props }) {
                        return (
                          <Box
                            component="pre"
                            sx={{
                              bgcolor: '#f6f8fa',
                              p: 2,
                              borderRadius: 2,
                              overflowX: 'auto',
                              fontFamily: 'monospace',
                              fontSize: '0.85rem',
                              whiteSpace: 'pre',
                            }}
                            {...props}
                          >
                            {children}
                          </Box>
                        );
                      },
                    }}
                  >
                    {entry.text}
                  </ReactMarkdown>
                  
                  ) : (
                    entry.text
                  )}
                </Box>
              </Box>
            ))}
          </Stack>
        </Box>

        <Box component="form" onSubmit={(e) => { e.preventDefault(); sendMessage(); }} sx={{ display: 'flex', gap: 1 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={loading}
            size="small"
            multiline
            maxRows={4}
          />
          <Button
            variant="outlined"
            onClick={sendMessage}
            disabled={loading}
            endIcon={loading && <CircularProgress size={18} />}
            sx={{ minWidth: 100 }}
          >
            {loading ? '...' : 'Send'}
          </Button>
        </Box>
      </Container>
    </Box>
  );
}

export default ChatApp;