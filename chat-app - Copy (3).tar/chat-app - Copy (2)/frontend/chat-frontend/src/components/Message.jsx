import React from "react";

function Message({ msg }) {
  const isUser = msg.kind === "request";

  const renderContent = (text) => {
    // Match code blocks enclosed in triple backticks
    const codeBlockRegex = /```([\s\S]*?)```/g;

    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ type: "text", content: text.slice(lastIndex, match.index) });
      }
      parts.push({ type: "code", content: match[1] });
      lastIndex = codeBlockRegex.lastIndex;
    }

    if (lastIndex < text.length) {
      parts.push({ type: "text", content: text.slice(lastIndex) });
    }

    return parts.map((part, i) =>
      part.type === "code" ? (
        <pre
          key={i}
          style={{
            backgroundColor: "#f4f4f4",
            padding: "0.75rem",
            borderRadius: "8px",
            fontFamily: "monospace",
            overflowX: "auto",
            margin: "0.5rem 0",
            border: "1px solid #ddd",
          }}
        >
          <code>{part.content}</code>
        </pre>
      ) : (
        <p key={i} style={{ margin: "0.25rem 0" }}>{part.content}</p>
      )
    );
  };

  const messageContent = msg.parts.map((part) => renderContent(part.content));

  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        marginBottom: "1rem",
      }}
    >
      <div
        style={{
          backgroundColor: isUser ? "#f0f0f0" : "transparent",
          borderRadius: isUser ? "16px" : "0px",
          padding: isUser ? "0.75rem 1rem" : "0",
          maxWidth: "70%",
          fontSize: "1rem",
          lineHeight: "1.5",
          whiteSpace: "pre-wrap",
        }}
      >
        {messageContent}
      </div>
    </div>
  );
}

export default Message;
