import React from "react";
import Message from "./Message";

function ChatWindow({ messages, userInput, setUserInput, onSend }) {
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        backgroundColor: "#fdfdfd",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: "1rem",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "600px",
          height: "90vh",
          display: "flex",
          flexDirection: "column",
          border: "1px solid #e0e0e0",
          borderRadius: "8px",
          backgroundColor: "#fafafa",
          position: "relative",
        }}
      >
        {/* Scrollable message area */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "1rem",
            paddingBottom: "5rem", // makes space for the input so last message isn’t hidden
          }}
        >
          {messages.map((msg, idx) => (
            <Message key={idx} msg={msg} />
          ))}
        </div>

        {/* Fixed input area */}
        <div
          style={{
            position: "absolute",
            bottom: "1rem",
            left: "1rem",
            right: "1rem",
            backgroundColor: "#fff",
            border: "1px solid #ccc",
            borderRadius: "999px",
            padding: "0.5rem 0.75rem",
            boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            display: "flex",
            alignItems: "center",
          }}
        >
          <input
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Send a message"
            style={{
              flex: 1,
              border: "none",
              outline: "none",
              fontSize: "1rem",
              padding: "0.5rem",
              backgroundColor: "transparent",
            }}
          />
          <button
            onClick={onSend}
            style={{
              marginLeft: "0.5rem",
              padding: "0.4rem 0.9rem",
              borderRadius: "999px",
              backgroundColor: "#10a37f",
              color: "#fff",
              border: "none",
              fontWeight: "bold",
              cursor: "pointer",
              fontSize: "0.9rem",
            }}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}

export default ChatWindow;
