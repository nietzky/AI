import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";

function App() {
  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const res = await fetch("http://localhost:8000/sessions");
      const data = await res.json();
      setSessions(data);
    } catch (err) {
      console.error("Error fetching sessions:", err);
    }
  };

  const handleSessionClick = (session) => {
    setActiveSessionId(session.session_id);
    setMessages(session.messages);
  };

  const handleSend = async () => {
    if (!userInput.trim()) return;

    const newSessionId = activeSessionId || `session-${Date.now()}`;
    const requestPayload = {
      session_id: newSessionId,
      message: userInput,
    };

    try {
      const res = await fetch("http://localhost:8000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestPayload),
      });

      const data = await res.json();

      const userMessage = {
        kind: "request",
        parts: [{ part_kind: "user-prompt", content: userInput }],
      };

      const botMessage = {
        kind: "response",
        parts: [{ part_kind: "text", content: data.message }],
      };

      setMessages([...messages, userMessage, botMessage]);
      setUserInput("");
      setActiveSessionId(newSessionId);

      if (!activeSessionId) {
        fetchSessions();
      }
    } catch (err) {
      console.error("Error sending message:", err);
    }
  };

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSessionClick={handleSessionClick}
      />
      <ChatWindow
        messages={messages}
        userInput={userInput}
        setUserInput={setUserInput}
        onSend={handleSend}
      />
    </div>
  );
}

export default App;
